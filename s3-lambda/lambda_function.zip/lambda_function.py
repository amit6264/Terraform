def lambda_handler(event, context):
    print("S3 Triggered!")
    print(event)
